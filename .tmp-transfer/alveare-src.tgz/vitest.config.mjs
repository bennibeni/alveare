import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["tests/unit/**/*.test.js"],
    environment: "node",
    testTimeout: 120_000, // alcune prove giocano partite intere
  },
});

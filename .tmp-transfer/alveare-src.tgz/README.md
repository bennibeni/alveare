# Alveare

Puzzle a esagoni **ispirato a Hex FRVR**: si appoggiano pezzi su un tabellone esagonale di 61 celle e si
svuotano le linee complete nelle tre direzioni. Include un autogioco, una modalità **Esperto** a coda e due
pagine che spiegano nel dettaglio come il computer sceglie le mosse.

Next.js (App Router) · React 19 · Tailwind CSS 4 · react-toastify.

## Avvio

```bash
npm install
npm run dev          # http://localhost:3000
```

## Comandi

| Comando                       | Cosa fa                                                                 |
| ----------------------------- | ----------------------------------------------------------------------- |
| `npm run dev`                 | server di sviluppo                                                      |
| `npm run build` / `npm start` | build di produzione e avvio                                             |
| `npm run lint`                | ESLint (regole Next.js)                                                 |
| `npm test`                    | test unitari (Vitest): griglia, pezzi, strategia, regressioni           |
| `npm run test:e2e`            | test nel browser (Playwright): avvia da solo build e server             |
| `npm run sim -- …`            | simulatore: fa giocare l'autogioco e riassume i risultati               |
| `npm run pericolo -- …`       | tasso di sconfitta con lo sdoppiamento nei momenti di pericolo          |
| `npm run audit -- …`          | controllo di congruenza di suggerimenti e giudizi su posizioni simulate |

Per i test nel browser serve Chromium di Playwright (`npx playwright install chromium`), oppure un Chromium già
installato indicato con `PW_CHROMIUM=/percorso/chrome`.

### Simulatore

```bash
npm run sim -- --mode expert --games 100          # 100 partite in modalità Esperto
npm run sim -- --mode normal --games 20 --max 400 # 20 partite normali da 400 pezzi
npm run sim -- --mode expert --seed 123 --json risultati.json
```

Ogni partita usa un seme: con gli stessi semi due strategie ricevono **esattamente gli stessi pezzi**, quindi si
possono confrontare partita per partita (`pairedCompare` in `scripts/sim-lib.mjs`).

### Misura con lo sdoppiamento

La strategia perde circa una volta ogni 10.000 pezzi: per confrontare due versioni contando le partite
perse servirebbero decine di ore. `scripts/pericolo.mjs` gioca le partite normalmente e, ogni volta che una
scende sotto 32 celle libere (dopo essere stata ad almeno 40), gioca quella posizione altre K volte con
pezzi futuri diversi, finché torna a 40 celle libere o si blocca. Tasso di sconfitta = ingressi in pericolo
ogni 1000 pezzi × frazione di copie bloccate. Così il calcolo si concentra dove si decidono le partite. Le
partite girano in parallelo, una per core.

```bash
npm run pericolo -- --games 300 --json base.json                          # strategia attuale
npm run pericolo -- --games 300 --game ../game-prova --json prova.json    # copia modificata di game/
npm run pericolo -- --confronta base.json prova.json                      # rapporto dei tassi, intervallo 95%
```

Per provare una modifica si copia `game/` in `game-prova/` (ignorata da git), si cambia
`game-prova/strategy.js` (o `pieceAvailability.js`) e si misura con gli stessi semi. Se l'intervallo del
rapporto comprende 1, la differenza non è dimostrata. I file salvati elencano anche le trappole: ingressi
in pericolo con almeno una copia bloccata (seme e pezzo).

Su 40 partite (4 copie per ingresso): 493 ingressi in pericolo (13 ogni 1000 pezzi), 25 copie bloccate su
1.972, tasso 0,165 ogni 1000 pezzi (intervallo 0,084–0,265); conteggio diretto 4 partite perse su 37.790
pezzi (0,106). Per riconoscere un miglioramento di un terzo servono circa 300 partite.

Su 300 partite (semi da `7000`, strategia prima del pezzo nuovo alla seconda mossa): 3.660 ingressi
in pericolo (12,9 ogni 1000 pezzi), 144 copie bloccate su 14.640, tasso 0,127 ogni 1000 pezzi
(intervallo 0,098–0,157); conteggio diretto 43 partite perse su 282.953 pezzi (0,152). La misura è
riproducibile: lo stesso comando su un altro computer ha dato esattamente gli stessi numeri.

## Struttura

Il pulsante **Scarica log partita** esporta un JSON della partita al momento del clic:
per ogni mossa include tabellone e vassoio ordinato prima di giocare, slot e coordinate
della mossa giocata, giudizio, suggerimenti valutati e risultato con punteggio.
Include le mosse dell’autogioco ed esclude quelle annullate. Una nuova partita o un
cambio di modalità azzera il registro. Le analisi mancanti vengono calcolate al download.
A partita finita, in modalità normale, il log contiene anche il vassoio finale (`finalTray`) e
l’autopsia (`autopsy`): esito di ogni mossa della discesa finale con i pezzi arrivati, rischio della
mossa scelta e della più sicura, mossa decisiva, errore più costoso e pezzi arrivati.

A fine partita, in modalità normale, il riquadro **Autopsia della partita** usa lo stesso registro: i
pezzi arrivati sono tutti noti, e un oracolo che li conosce in anticipo (`game/autopsy.js`, nel worker
`autopsy.worker.js`) dice per ogni mossa della discesa finale se c’era ancora una via d’uscita fino a
40 celle libere (verde), se con i pezzi arrivati si poteva continuare (giallo) o se non c’era scampo
(rosso). Indica la mossa decisiva, le mosse che da lì evitavano il blocco e la sequenza dell’oracolo.
Per ogni mossa scelta mostra posizione e vassoio (con i posti di ogni pezzo), un giudizio
dettagliato (`autopsyText.js`) e tutte le mosse possibili con il rischio di ognuna: quota di 200
futuri a caso, gli stessi per tutte le mosse, in cui nemmeno l’oracolo torna a 40 celle libere,
accanto alla stima di blocco del suggerimento, ai «pari merito» (entro 2 punti dalla più sicura) e
all’esito con i pezzi arrivati; sotto, i pezzi arrivati dopo la mossa. Se la mossa decisiva era
sicura con pezzi qualsiasi, il verdetto la attribuisce alla sfortuna. Il pulsante
«Vuoi sapere qual è stato l’errore più costoso?» apre una finestra con il rischio aggiunto da ogni
mossa della discesa finale rispetto alla mossa più sicura e indica la mossa con il distacco maggiore.
È lo stesso oracolo degli script di `scripts/autopsia/`, limitato ai pezzi usciti davvero.

L’analisi delle mosse contiene il pulsante **Calcola indicatori di prosecuzione**.
Mostra la probabilità esatta che un pezzo estratto non entri sulla griglia attuale
(pesata per ogni orientamento), e stime del blocco prima di completare 3 e 6 mosse.
Le stime usano 128 simulazioni con seme fisso e una politica euristica di sopravvivenza:
il futuro viene estratto solo dopo ogni scelta, con le regole della modalità attiva
e cancellazione delle linee. Non sono probabilità con gioco ottimo né previsioni calibrate
sul giocatore. Gli intervalli Wilson al 95% descrivono solo l’incertezza campionaria.

Il margine riporta le candidate con rischio stimato entro 6 mosse non superiore al 25%,
su un massimo di 8 candidate approfondite (64 simulazioni ciascuna, includendo sempre
la mossa giocata). Il totale delle mosse legali resta distinto: il campione non è esaustivo.
Sono indicate anche le candidate sotto soglia con tutto l’intervallo di confidenza.
I parametri sono in `game/positionRisk.js`. Il calcolo avviene in un Web Worker su richiesta;
la copia del giudizio lo esegue o riutilizza il risultato e lo include nel log diagnostico.
I giudizi non vengono ricalibrati automaticamente su queste stime sperimentali.

L’accordion **Analisi delle mosse**, sopra le istruzioni, è disponibile fuori dall’autogioco.
Mostra il numero di mosse legali e le candidate approfondite dalla strategia attuale, ordinate
con il suggerimento in testa: in modalità normale le 6 migliori per totale fra le 20 approfondite;
in Esperto fino a 10 posizioni del
primo pezzo, ciascuna approfondita con la propria ricerca e mostrata con il punteggio della sua
migliore sequenza.
Il punteggio è quello della strategia, non i punti aggiunti alla partita. L’analisi viene calcolata
solo aprendo l’accordion, in un Web Worker (`game/strategy.worker.js`): mentre calcola il riquadro
mostra «Calcolo delle mosse…» e il gioco resta fluido. Per disabilitarlo da codice, impostare `SHOW_MOVE_ANALYSIS = false`
in `game/HexBlockPuzzle.jsx`.

Dopo una mossa manuale l’accordion mostra il confronto sulla posizione precedente:
la mossa giocata è evidenziata, oppure aggiunta in fondo e valutata con gli stessi criteri
se non era fra le candidate. La valutazione usa solo i pezzi noti prima della mossa.
I pulsanti «Ultima mossa» e «Posizione corrente» permettono di passare dal confronto
alle nuove possibilità. Il suggerimento e la sua ricerca restano invariati.

Il **toast di valutazione** compare dopo ogni mossa manuale, anche con l’accordion chiuso.
Analisi e giudizio della mossa si calcolano nello stesso worker, quindi il toast arriva
qualche istante dopo la mossa senza bloccare l’interfaccia; il suggerimento e l’autogioco
restano invece sul thread principale.
Su desktop occupa una colonna riservata a destra; sotto 1100 px resta nel flusso sotto
il tabellone, prima degli accordion. Rimane leggibile fino alla mossa successiva o alla
chiusura e non impila notifiche. `SHOW_MOVE_FEEDBACK` abilita/disabilita questa funzione
indipendentemente dall’accordion. Durante l’autogioco non valuta né suona.
Tutti i giudizi mostrano inizialmente solo il titolo, cliccabile per aprire i dettagli.
Ogni nuova mossa parte con i dettagli chiusi, anche quando il giudizio è positivo.

Il rapporto mostrato è `voto della mossa / massimo fra le mosse valutate`, inclusa
la mossa aggiunta al confronto: non è una percentuale né il massimo globale di tutte
le mosse legali. Il giudizio usa **lo stesso metro del suggerimento**: l’etichetta dipende solo
dai voti delle mosse valutate e dal rischio di blocco. Così una mossa con un voto più alto e
non più rischio non riceve mai un giudizio peggiore di un’altra, e il suggerimento non viene
mai criticato. I conti sono in `game/moveJudgment.js`.

- La scala di confronto è il massimo fra 1, valore assoluto del massimo e della mediana;
  in questo modo anche voti zero o negativi hanno un confronto definito.
- Alternative entro ±5% della scala sono comparabili; «nettamente migliori» sono quelle con un
  vantaggio oltre il 20% (della scala, o del valore della mossa se più grande). Il rango usa i
  punteggi effettivi con una piccola tolleranza numerica per gli ex aequo.
- Il rischio è la probabilità di blocco subito dopo i pezzi noti. In Esperto: il pezzo
  ignoto che segue i tre della coda non entra. In normale: dopo la mossa e la migliore
  seconda mossa, il pezzo noto rimasto non entra e nemmeno i due estratti al posto di quelli
  giocati (probabilità per un pezzo, al quadrato).

Le etichette, nell’ordine in cui si controllano:

| Etichetta                           | Quando                                                                                                                                                                                                                                 |
| ----------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Mossa obbligata                     | era l’unica mossa legale                                                                                                                                                                                                               |
| Mossa pessima / cattiva / rischiosa | rischio di blocco più alto di almeno 20 punti percentuali rispetto all’alternativa più sicura (pessima: blocco con i pezzi noti, o rischio ≥ 80%; cattiva: ≥ 50%)                                                                      |
| Occasione persa                     | un’alternativa vale almeno il 50% della scala in più, oppure distacco ≥ 30% con almeno due alternative nettamente migliori (e almeno due terzi delle valutate); in entrambi i casi solo se la migliore delle valutate è «Ottima mossa» |
| Ottima mossa / Ottima scoperta      | prima, almeno metà delle alternative inferiori, vantaggio sulla mediana ≥ 10%, rischio sotto il 20% («scoperta»: mossa che il suggerimento non aveva fra le candidate)                                                                 |
| Una mossa vale l’altra              | tutte le alternative sono comparabili                                                                                                                                                                                                  |
| Migliore disponibile                | prima, ma con rischio di blocco ≥ 20%                                                                                                                                                                                                  |
| Buona mossa                         | distacco ≤ 5% e rischio sotto il 20%                                                                                                                                                                                                   |
| Mossa giocabile                     | distacco ≤ 10%                                                                                                                                                                                                                         |
| Mossa discreta                      | la maggioranza delle alternative non è migliore, oppure distacco < 20%                                                                                                                                                                 |
| Mossa migliorabile                  | tutti gli altri casi                                                                                                                                                                                                                   |

Le osservazioni sulla posizione compaiono come **note** nei dettagli, senza cambiare l’etichetta:
linea eliminata aumentando lo spazio, incastro pulito, pezzo da una cella consumato senza un
netto miglioramento. Quest’ultima compare solo se un’alternativa con un voto migliore conservava
il punto (o lo collocava eliminando linee): penalizzare nella strategia il consumo del punto senza
linee, provato con 30 e 100 su 60 partite, non migliora (durata media 882 e 865 contro 904).
Prima queste osservazioni potevano scavalcare il voto: un incastro o una linea eliminata
diventavano «Buona mossa» anche con alternative nettamente migliori, e il punto consumato
diventava «Mossa cattiva» anche quando era il suggerimento. Ora che la strategia premia già le
linee svuotate e quelle preparate, quelle eccezioni producevano giudizi incoerenti.

`npm run audit` controlla la congruenza su posizioni simulate (in parte con mosse casuali): in
ogni posizione giudica le candidate e alcune mosse casuali e verifica che suggerimento, etichetta,
motivazione, note e mosse nettamente migliori siano coerenti con i dati. Una versione corta gira
fra i test (`tests/unit/coherence.test.js`).

```bash
npm run audit -- --mode normal --positions 400   # da 2 a 5 minuti, secondo il computer
npm run audit -- --mode expert --positions 150
```

Il **beep è disattivato inizialmente** e si può attivare dal riquadro. Produce due brevi
toni ascendenti/discendenti solo per le mosse evidenziate positivamente/negativamente;
aprire guide, annullare o riaprire un’analisi non ripete un suono già valutato.

```
app/                  layout, pagina, stili globali, icona
game/
  HexBlockPuzzle.jsx  interfaccia: menu, gioco, vassoio, voli, autogioco, avvisi
  HexGrid.js          tabellone in coordinate assiali: celle, vicini, 27 linee, mosse
  pieces.js           i 25 pezzi (6 forme), colori, estrazione casuale (anche con seme)
  strategy.js         suggerimenti: valutazione del tabellone, sguardo avanti, beam search (Esperto)
  strategy.worker.js  analisi e giudizio delle mosse fuori dal thread dell’interfaccia
  strategyClient.js   richieste al worker, con cache per posizione
  moveJudgment.js     giudizio della mossa giocata
  pieceAvailability.js probabilità esatta che il prossimo pezzo estratto non entri (usata da strategia e indicatori)
  positionRisk.js     indicatori di prosecuzione (simulazioni nel worker positionRisk.worker.js)
  GuideNormal.jsx     pagina «Suggerimenti · normale»
  GuideExpert.jsx     pagina «Suggerimenti · Esperto»
  GuideKit.jsx        miniature del tabellone e componenti comuni delle guide
  GameAutopsy.jsx     autopsia della partita (modalità normale), con autopsy.js nel worker
data/                 archivi per misure e test, descritti in data/README.md
scripts/              motore di simulazione e simulatore da riga di comando
  autopsia/           autopsia delle sconfitte con l’oracolo chiaroveggente (vedi più sotto)
tests/unit/           test Vitest
tests/e2e/            test Playwright
```

## Risultati di riferimento (simulatore)

Confronto appaiato: con lo stesso seme le strategie ricevono gli stessi pezzi nello stesso ordine.
Le partite hanno durate molto variabili, da poche decine a oltre mille pezzi, quindi una differenza
è credibile solo su molte partite.

### Modalità normale

60 partite di taratura (semi `7000`, `9000`, `11000`, 20 ciascuno, al massimo 1.000 pezzi):

| Strategia                                              | Durata media | Durata mediana | Punti medi | Punti per pezzo | Arrivate a 1.000 |
| ------------------------------------------------------ | ------------ | -------------- | ---------- | --------------- | ---------------- |
| originale (6 candidate, senza rischio)                 | 286          | 219            | 2.896      | 10,13           | 0                |
| 6 candidate, rischio 400                               | 373          | 301            | 3.834      | 10,29           | 5                |
| 20 candidate, rischio 1.600                            | 433          | 357            | 5.226      | 12,06           | 10               |
| + spazio per il pezzo rimasto                          | 486          | 349            | 5.938      | 12,21           | 14               |
| + spazio per rombo e ferro di cavallo                  | 670          | 735            | 8.188      | 12,23           | 23               |
| + premio per le linee svuotate                         | 852          | 1.000          | 8.982      | 10,54           | 43               |
| + premio per le linee chiudibili                       | 904          | 1.000          | 9.591      | 10,61           | 46               |
| **attuale: + tre pezzi noti con la griglia affollata** | **966**      | **1.000**      | **10.312** | **10,68**       | **56**           |

Verifica su 140 partite mai usate per la taratura (semi da `13000` a `25000`):

| Strategia                                                            | Durata media | Durata mediana | Arrivate a 1.000 | Meglio / peggio |
| -------------------------------------------------------------------- | ------------ | -------------- | ---------------- | --------------- |
| + spazio per il pezzo rimasto                                        | 479          | 416            | 24               | —               |
| + spazio per rombo e ferro di cavallo                                | 604          | 653            | 44               | 73 / 58         |
| + premio per le linee svuotate                                       | 832          | 1.000          | 96               | 87 / 28         |
| + premio per le linee chiudibili                                     | 879          | 1.000          | 110              | 86 / 19         |
| **attuale: + tre pezzi noti con la griglia affollata** (100 partite) | **952**      | **1.000**      | **88 su 100**    | **19 / 11**     |

«Meglio / peggio» confronta ogni riga con la precedente; per i due premi per le linee, con la versione
senza (rapporto delle durate 1,77, intervallo al 95% 1,47–2,13). Il premio per le linee chiudibili,
aggiunto al premio per le linee svuotate, vale circa +11% su 200 partite (55 meglio, 38 peggio; intervallo
0,98–1,25: credibile ma non certo). Con tre quarti delle partite fermate al limite dei 1.000 pezzi, i
guadagni sono sottostimati.

I tre pezzi noti sono stati verificati su 100 delle 140 partite nuove (semi `13000`, `15000`, `17000`,
`21000`, `23000`): partite perse da 19 a 12, meglio in 19 e peggio in 11 (rapporto delle durate 1,12,
intervallo 0,98–1,29). Con le 60 partite di taratura (perse da 14 a 4, meglio 13, peggio 4): 32 meglio e
15 peggio su 160 partite, test dei segni p ≈ 0,02. Sulle 30 partite del seme `19000`, rimaste fuori dalla
verifica interrotta, le partite perse sono passate da 9 a 1.

Che cosa fa il suggerimento in modalità normale, e perché:

- **20 candidate invece di 6.** Il voto a un passo, usato per sceglierle, prevede male il totale finale:
  con 6 il suggerimento era il migliore secondo il suo stesso criterio solo nel 59% delle posizioni
  (87% con 20). Analisi e giudizio mostrano e confrontano le 6 migliori per totale.
- **Rischio del pezzo in arrivo: 1.600 × probabilità** che un pezzo estratto a caso non entri dopo le
  due mosse (provati 400, 800, 1.600, 2.400, 3.200: durata media 364, 380, 433, 396, 371).
- **Spazio per il pezzo che resta nel vassoio: 200 × (1 − posizioni / 6).** Su 26.000 posizioni
  simulate, se i due pezzi tenuti hanno al massimo 3 posizioni la partita si perde entro 5 mosse nel
  1–2% dei casi, contro lo 0,1% con almeno 4; con due pezzi identici (stesso orientamento, non punti)
  senza posizioni si perde nel 55% dei casi. Su 200 partite: durata media 420 → 481 (113 meglio, 83 peggio).
- **Spazio per rombo e ferro di cavallo: 1.000 × (1 − spazio).** Nel vassoio a fine partita queste due
  forme sono il 31–32% dei pezzi, contro il 22% con cui escono (98 partite perse): sono compatte e
  servono buchi «a blocco», mentre alla fine restano in media 25 celle libere ma sparpagliate.
  Spazio = media, pesata con le probabilità di uscita, di min(posizioni, 6) / 6 sui loro orientamenti.
  Provati 200, 500, 1.000, 2.000 (durata media 557, 554, 670, 610) e la stessa misura su tutti i
  pezzi (300 e 1.000: 599 e 629).
- **Premio per le linee svuotate: 180 × linee × affollamento.** Affollamento = celle occupate / 61,
  prima della mossa. A tabellone vuoto conviene rimandare lo svuotamento per fare combo; a tabellone
  pieno conviene liberare spazio subito. Provati 60, 180, 240, 300, 500 (durata media 729, 852, 826, 777, 770) e 180 solo sotto le 40 celle libere (747). Si fanno meno combo (punti per pezzo da 12,2 a 10,5),
  ma le partite durano molto di più e i punti per partita salgono.
- **Premio per le linee chiudibili: 100 × linee chiudibili × affollamento,** dopo le due mosse. Linee
  chiudibili = numero atteso di linee (a cui mancano da 1 a 3 celle) che un pezzo estratto a caso può
  chiudere con una sola mossa: premia le mosse che preparano uno svuotamento. Da solo rende poco (100 e
  300: 705 e 753); insieme al premio per le linee svuotate, 100 rende più di 300 (904 e 830). Contare
  le linee che può chiudere il pezzo rimasto nel vassoio non ha dato miglioramenti (675).
- **Tre pezzi noti con la griglia affollata (meno di 40 celle libere; fino al 10 ottobre 36).** Su 26.000 mosse simulate il
  rischio di perdere entro 10 mosse è ≤ 0,1% con almeno 40 celle libere, 0,4% con 36–39, 1,8% con
  32–35, 5% con 28–31, 12% con 24–27. Sotto le 36 la strategia prova, per ogni candidata, le 5 migliori
  seconde mosse e per ognuna le 3 migliori terze mosse con il pezzo rimasto; il tabellone finale si
  giudica come quello dopo la seconda mossa, con penalità 1.000 se il terzo pezzo non entra. Sono meno
  di una mossa su dieci, quindi il tempo per mossa cresce poco. Provati: soglia 40 (952, 7 perse),
  ricerca più larga 8 × 5 (941, 6 perse), penalità 300 (941, 6 perse) e 1.000 (966, 4 perse).
- **Pezzo nuovo alla seconda mossa (fra 40 e 44 celle libere; prima fra 36 e 44).** Dopo la prima mossa entra un pezzo
  nuovo, e la seconda mossa si può fare anche con quello: lo sguardo a due pezzi lo ignorava. Le 8
  migliori candidate si rivalutano provando i 25 pezzi che possono arrivare (per ognuno, la migliore
  seconda mossa fra i due noti e il nuovo) e prendendo la media pesata. Su 300 partite con lo
  sdoppiamento, stessi semi: ingressi in pericolo da 12,9 a 10,1 ogni 1000 pezzi (rapporto 0,78,
  intervallo 0,74–0,82), copie bloccate per ingresso da 0,98% a 1,09% (1,11, intervallo 0,77–1,56),
  tasso 0,127 → 0,110 (0,86, intervallo 0,60–1,22), partite perse 43 → 29 (38 perse solo prima, 24
  solo dopo; test dei segni p ≈ 0,10). Verifica su altri 300 semi (da `40000`): tasso 0,136 → 0,097
  (0,71, intervallo 0,50–1,03), partite perse 33 → 29. Sulle 600 partite insieme: ingressi in pericolo
  0,77 (0,74–0,79), copie bloccate per ingresso 1,02 (0,80–1,31), tasso 0,132 → 0,103 (0,78,
  intervallo 0,61–1,00), partite perse 76 → 58 (70 solo prima, 52 solo dopo; p ≈ 0,12). Circa −22%
  di sconfitte, al limite della significatività ma uguale sui due gruppi di semi; sulle 30 partite
  del seme `19000` va invece peggio (4 perse contro 1, durata media 953 contro 981). Costo: circa 22 ms per mossa invece di 6. Sotto le 36
  celle libere la ricerca a tre pezzi ignora ancora i pezzi in arrivo.
- **Pezzi identici nel vassoio** (stessa forma e stesso orientamento, in circa un vassoio su sei): le
  loro mosse si generano una volta sola. Prima la stessa mossa poteva occupare due posti fra le 20
  candidate approfondite e comparire due volte fra le 6 mostrate (in 168 posizioni su 1.000). Su 300
  partite con lo sdoppiamento (semi da `40000`) la forza non cambia: tasso 0,097 → 0,106 (1,09,
  intervallo 0,76–1,59), partite perse 29 e 29, ingressi in pericolo 0,97 (0,92–1,02).
- **Pari merito nella zona di pericolo** (sotto 40 celle libere): con i tre pezzi noti giocati in
  ordine diverso più prime mosse portano spesso allo stesso tabellone finale, e lo sguardo a tre pezzi
  dà a tutte lo stesso totale; vinceva la prima della lista. Ma fra la prima e la seconda mossa arriva
  un pezzo nuovo, e il tabellone dopo la prima mossa conta (celle isolate, spazio per i pezzi). Ora le
  pari merito si ordinano con il pezzo nuovo alla seconda mossa (media sui 25 pezzi, come fra 40 e 44
  celle libere), e il loro totale scende della differenza: il giudizio le distingue. Esempio: seme
  7000, pezzo 2891: rombo, ferro e ferro avevano −703 tutti e tre ed era suggerito il rombo che isola
  la cella 61 (bloccato nel 16% di 2000 futuri, i ferri nel 14%); ora vince il ferro in 45-51-57-58.
  Su 300 partite con lo sdoppiamento (semi da `40000`): tasso 0,106 → 0,101 (0,95, intervallo
  0,68–1,31), partite perse 29 → 19, stesso tempo di calcolo.
- **Rischio imparato (autoapprendimento)**, in prova sul ramo `prova/rischio-imparato`: il voto del
  tabellone finale dello sguardo avanti non usa più pesi e penalità scritti a mano (celle isolate,
  pezzi che entrano, linee quasi piene, pezzo nuovo che non entra, spazio per rombo e ferro, linee
  chiudibili), ma punti e linee dell'ultima mossa − 1.600 × la probabilità di blocco imparata dal
  programma (`game/learnedRisk.js`). Come si impara (`scripts/apprendimento`): 1.819 posizioni
  affollate dalle partite della strategia, più 5 tabelloni da ciascuna con mosse a caso; per ognuno
  16 futuri con un vassoio a caso giocati da un giocatore veloce, contando quanti si bloccano prima di
  tornare a 46 celle libere; regressione logistica su 19 misure (celle vuote, celle morte che nessun
  pezzo da 4 copre, buchi, zone da 1–3 celle, linee a cui mancano 1–3 celle, pezzi che entrano,
  rischio del pezzo nuovo, spazio per ogni forma, linee chiudibili). Sdoppiamento, 600 partite (semi
  `40000` e `70000`): tasso 0,094 → 0,065 (0,69, intervallo 0,50–0,93), ingressi in pericolo 9,5 →
  5,5 ogni 1000 pezzi (0,58, 0,56–0,61), partite perse 42 → 37, stesso tempo di calcolo. Un secondo
  giro (posizioni e futuri giocati con il modello appena imparato) non ha migliorato oltre: tasso
  0,079 contro 0,068 sui semi `40000`. Effetto collaterale da sistemare: su tabelloni sgombri i totali
  sono piccoli e il giudizio è più severo («Occasione persa» per il 44% delle mosse giudicate dal
  controllo di congruenza, contro il 25%). Provato e scartato prima: scegliere i pesi del voto a forza
  di partite (entropia incrociata, come per Tetris); le differenze fra serie di pesi erano più piccole
  del caso.
- **Preselezione per pezzo** (ramo `prova/rischio-imparato`): oltre alle 20 mosse migliori per voto a
  un passo si approfondiscono le 3 migliori di ogni pezzo diverso del vassoio. A voti quasi uguali un
  pezzo intero restava fuori: a tabellone vuoto, con bandiera e due ferri, le 20 approfondite erano
  tutte mosse della bandiera (voto 80,8 contro 79,6), mentre due mosse del ferro pareggiano con la
  migliore. Sdoppiamento, 300 partite (semi da `40000`): tasso 0,068 -> 0,051 rispetto al solo rischio
  imparato (0,76, intervallo 0,46–1,24), 0,101 -> 0,051 rispetto allo spareggio (0,51, intervallo
  0,32–0,79), partite perse 19. Provata e scartata con essa una soglia (rischio imparato solo sotto 45
  celle libere): tasso 0,074 (1,44 rispetto alla preselezione).
- **Copertura dei bordi** (seconda versione del rischio imparato): due misure in più per il
  rischio imparato, le celle vuote a copertura bassa (sotto il 15% di probabilità che un pezzo da 4
  estratto a caso le copra, di solito solo la barra parallela al lato) sul bordo e all'interno.
  Analisi su 8.226 posizioni: una cella di bordo a copertura bassa pesa quanto una cella morta (circa
  una cella libera in meno), una interna quasi nulla. Riaddestrato su 2.044 posizioni della strategia
  attuale (12.000 tabelloni, 192.000 futuri; modello in `docs/modello-copertura.json`): previsione
  appena migliore (log-loss 0,2120 -> 0,2116, l'informazione c'era già nello spazio per forma).
  Sdoppiamento, 300 partite (semi da `40000`): tasso 0,051 come la preselezione (1,00, intervallo
  0,56–1,73), ingressi in pericolo 5,6 -> 6,9 ogni 1000 pezzi, copie bloccate per ingresso 0,93% ->
  0,74%.
  Secondo giro, anche su tabelloni poco affollati (al massimo 45 celle libere: 3.348 posizioni,
  10.044 tabelloni, 80.352 futuri) e con un'altra domanda, «si blocca entro 40 mosse?» (`valori.mjs
  --safe 99 --orizzonte 40`; modello in `docs/modello-sgombri.json`). Sdoppiamento, 300 partite (semi
  da `40000`): con penalità 1.600 tasso 0,051 -> 0,040 (0,78, intervallo 0,45–1,29), partite perse
  19 -> 10; con penalità 3.200 tasso 0,035 (0,68, intervallo 0,35–1,20), partite perse 17. Migliori
  ma non ancora dimostrati. Conferma su altri 300 semi (da `70000`), penalità 1.600: tasso 0,048 ->
  0,035 (0,73, intervallo 0,40–1,33), partite perse 15 e 15. Sulle 600 partite insieme: tasso 0,050 ->
  0,037 (0,76, intervallo 0,50–1,13), ingressi in pericolo 5,4 -> 7,0 ogni 1000 pezzi, copie bloccate
  per ingresso 0,92% -> 0,54%, partite perse 34 -> 25. Stessa direzione sui due gruppi di semi, ma non
  dimostrato.
  **Adottato** il 10 ottobre come seconda versione del rischio imparato (`game/learnedRisk.js`,
  descrizione in `docs/rischio-imparato.md`).
- **Tre pezzi noti sotto 40 celle libere invece che sotto 36.** Nelle partite perse (studio del seme
  7000) il tabellone crolla in pochi pezzi dopo essere sceso a 31 celle libere: lo sguardo a tre pezzi
  arrivava tardi. Su 300 partite con lo sdoppiamento (semi da `40000`), stesse partite: tasso 0,040 →
  0,014 (rapporto 0,36, intervallo 0,13–0,75: **dimostrato**), partite perse 10 → 4, trappole 33 → 11.
  Gli ingressi in pericolo raddoppiano (6,9 → 13,4 ogni 1000 pezzi), ma le copie bloccate per ingresso
  scendono da 0,58% a 0,11%. Il pezzo nuovo alla seconda mossa resta fra la soglia e 44 celle libere:
  spostarlo a 40–48 non ha aiutato (189 partite, 6 perse come prima). **Adottato** il 10 ottobre.
- **Provati e scartati:** premio per le celle libere dopo le due mosse (854 e 811), linee della
  seconda mossa premiate con l'affollamento (726 e 612), premio esponenziale con le celle libere al
  posto di quello lineare (851 e 850). Tenere la griglia vuota non è un obiettivo in sé, e premiare lo
  svuotamento alla mossa successiva fa rimandare.
- **Classificazione dei vassoi** (320 partite, 205.000 mosse; sconfitte entro 10 mosse osservate contro
  attese, con la griglia affollata): con il punto nel vassoio il rischio è molto più basso di quanto la
  strategia stimi (punto tenuto: 0 sconfitte contro 4,8 attese; coppie tenute con il punto: rapporto
  0,15–0,6), e due ferri di cavallo tenuti sono più pericolosi (rapporto 1,3–1,5). Trasformati in correzioni
  della strategia con la griglia affollata (meno di 40 celle libere), questi segnali **peggiorano**: penalità
  300 per consumare l'ultimo punto, 9 partite perse su 60 contro 4; penalità 100 per tenere due pezzi
  grandi uguali, 9 contro 4. Sull'archivio delle posizioni affollate la seconda sembrava utile (226 posizioni
  salvate contro 221): la misura sull'archivio guarda solo 20 mosse e posizioni scelte con la strategia
  attuale, quindi va sempre confermata sulle partite intere.
- **Celle vuote che solo il punto può riempire.** Con la griglia affollata l'83% delle posizioni ha almeno
  un gruppo isolato di 1–3 celle vuote (3,3 celle in media) e in media 4,6 celle che nessun pezzo da 4 può
  coprire. Penalità per cella nei gruppi di 1–3: 5 e 15 (perse su 60: 4 e 10, contro 4); penalità per cella
  non coperta da nessun pezzo da 4 (calcolo veloce con le posizioni precalcolate, 43 µs per tabellone): 10 e
  20 (8 e 4). Nessun miglioramento: buchi, celle isolate, pezzi che entrano e sguardo a tre pezzi coprono già
  questa debolezza. Sull'archivio la penalità 10 sembrava utile (229 posizioni salvate contro 221).
- **Pezzi noti rimasti nel rischio imparato.** Il rischio imparato è addestrato su futuri con un vassoio
  tutto nuovo, ma dopo le due mosse dello sguardo avanti il terzo pezzo noto resta nel vassoio. Aggiunte 4
  misure (pezzi noti rimasti, punto fra questi, spazio del pezzo noto più difficile, pezzo noto che non
  entra), passate da sguardo a due e a tre pezzi e pezzo nuovo; nuovi dati
  (17.038 tabelloni da 2.840 posizioni, ognuno con futuri a vassoio nuovo e con 1–2 pezzi noti tenuti).
  Effetto nella direzione attesa ma piccolo: con il punto tenuto si bloccano il 3,2% dei futuri contro il
  4,0% (coefficienti: punto −0,29, pezzo noto che non entra +0,48) e la previsione migliora in tutte e 5 le
  suddivisioni di prova, ma di pochissimo (log-loss −0,0002). Sdoppiamento, 600 partite: semi 40000 tasso
  0,014 -> 0,019 (rapporto 1,35, intervallo 0,61–3,67, perse 4 -> 6), semi 70000 0,028 -> 0,029 (rapporto
  1,06, intervallo 0,51–2,29, perse 9 -> 7); copie bloccate 50 -> 58. Nessun miglioramento: penalità per lo
  spazio del pezzo rimasto e sguardo a tre pezzi coprono già quasi tutto, e resta solo il punto, raro.
- **Quanto si può ancora misurare.** La strategia attuale perde 4 partite su 60 di taratura (al massimo
  1.000 pezzi): per riconoscere una riduzione di un terzo delle sconfitte servirebbero centinaia di partite,
  oppure partite più lunghe.

### Modalità Esperto

| Partite             | Strategia                                       | Durata media | Durata mediana | Punti medi | Punti per pezzo |
| ------------------- | ----------------------------------------------- | ------------ | -------------- | ---------- | --------------- |
| 50, max 3.000 pezzi | precedente (un fascio per tutte le prime mosse) | 369          | 310            | 3.434      | 9,30            |
| 50, max 3.000 pezzi | **attuale** (un fascio per prima mossa)         | 400          | 266            | 4.306      | 10,76           |

Semi `7000` (20) e `13000` (30). Con un fascio per ogni prima mossa la ricerca trova più sequenze che
svuotano linee, e con la penalità per il pezzo ignoto a 400 le partite si accorciavano: è passata a
1.200 (su 30 partite: 400 → durata media 310, 800 → 378, 1.200 → 434, 1.600 → 428; precedente 402).

### Archivio di posizioni affollate

`data/archivio-affollate.json` raccoglie 260 posizioni della modalità normale con meno di 36 celle
libere e un esito che **dipende dalla mossa scelta**: fra le 4 migliori mosse iniziali della strategia,
con gli stessi pezzi futuri, qualcuna arriva a 20 mosse e qualcuna si blocca prima. Serve per misurare
in poco tempo, e proprio dove si decidono le partite, se una strategia sceglie meglio.

- **Fonti:** partite della strategia attuale (27 posizioni), della strategia attuale con una mossa su
  tre casuale (115) e della strategia prima dei premi per le linee (118). Semi diversi da quelli di
  taratura e verifica delle partite intere.
- **Taratura e verifica:** divise per partita di origine, una partita su tre in verifica (172 e 88).
- **Quante servono:** su 3.900 posizioni affollate solo il 7% era decisiva; l'86% si salvava con
  qualunque delle migliori mosse, il 7% si perdeva comunque.
- **Riferimento:** con la strategia attuale (commit indicato in `strategyCommit`) la mossa suggerita
  si salva in 221 posizioni su 260. Gli esiti salvati dipendono dalla strategia usata per continuare.

Ogni posizione ha le celle occupate (coordinate e numeri del giudizio), i tre pezzi del vassoio, la
combo, il seme dei pezzi futuri (`futureSeed`) e l'esito delle mosse iniziali provate. Per rigenerarlo
o ingrandirlo: `scripts/crowded-archive.mjs` (istruzioni in testa al file).

### Autopsia delle sconfitte

Dove si decidono le sconfitte della modalità normale, e quanto resta da guadagnare? Gli script in
`scripts/autopsia/` (istruzioni in testa a ogni file) rigiocano le copie bloccate dello sdoppiamento
con un **oracolo chiaroveggente**: un motore a bit che conosce i pezzi futuri e cerca una sequenza di
mosse che torni ad almeno 40 celle libere entro 25 mosse (`verifica-motore.mjs` lo confronta con
`HexGrid.play`). Se nemmeno l'oracolo si salva, la sconfitta era inevitabile con quei pezzi.

Dati: 400 partite (semi da `100000`, al massimo 1.000 pezzi, 8 copie per ingresso in pericolo;
`data/autopsia/trappole-100000.json`): 395.358 pezzi, 5.360 ingressi in pericolo, 42.880 copie, 59
copie bloccate da 24 ingressi (tasso 0,019 ogni 1000 pezzi), 10 partite perse.

- **Tre sconfitte su quattro sono inevitabili già all'ingresso in pericolo** (`autopsia.mjs`): in 44
  copie su 59 nemmeno l'oracolo trova una sequenza salva. Si bloccano quasi tutte entro 1–3 mosse:
  sotto 32 celle libere rombo, ferro di cavallo, barra da 4 e bandiere hanno 0–3 posizioni.
- **Il passo fatale, quando c'è, è quasi sempre sfortuna** (`prova-fatale.mjs`). Nelle altre 15 copie
  c'è un'ultima mossa dopo la quale non c'è più scampo (in media 2 mosse salve su 6). Giudicate su
  60 futuri a caso, senza conoscerli, le mosse salve dell'oracolo non reggono meglio di quella della
  strategia in 13 casi su 15. Un solo errore probabile (due copie dallo stesso ingresso): 31 celle
  libere, bandiera destra, barra da 4, bandiera destra; la mossa scelta perde 39 futuri su 60, un'altra
  posizione della stessa bandiera 19–27.
- **Le mosse prima dell'ingresso risultavano quasi sempre migliori nella prova esplorativa** (`alternative.mjs`). Nelle ultime 3 mosse prima
  di ognuno dei 24 ingressi, per ogni mossa possibile, quota di 40 futuri in cui nemmeno l'oracolo
  sopravvive 14 mosse: la strategia sceglie la mossa migliore o una alla pari quasi sempre (le
  differenze sono di uno o due futuri su 40). Con 38–40 celle libere le mosse possibili sono già solo
  3–20.
- **Il margine che resta è piccolo** (`ingressi-oracolo.mjs`). Sugli stessi 1.273 ingressi delle prime
  100 partite l'oracolo non si salva nello 0,124% di 200 futuri per ingresso, la strategia si blocca
  nello 0,167% delle copie (17 su 10.184): anche chi conoscesse il futuro perderebbe circa tre quarti
  delle partite che perde la strategia (rapporto ancora impreciso: 17 copie bloccate). Il rischio è
  concentrato: 5 ingressi su 1.273 fanno il 91% dei futuri persi dall'oracolo.

Le misure storiche indicavano un margine piccolo. Le verifiche successive su futuri indipendenti
hanno però confermato scelte migliorabili, anche prima dell'ingresso in pericolo: gli esempi sono
conservati in `data/mosse-migliori.json`.

### Ricerca nei casi critici (7 novembre 2026)

Quando nessuna candidata permette un'altra mossa con i pezzi già visibili, la modalità normale
confronta gli stessi 24 futuri casuali fino a 8 mosse, soltanto se restano 2–8 candidate. Il totale
è la media dei punti, meno 1000 per ogni blocco; le continuazioni usano il motore ordinario.
Sceglie così la mossa confermata nel seme 108051. Le altre due nuove scoperte rimangono casi aperti.
La ricerca e i punteggi stimati sono indicati nell'analisi delle mosse; le posizioni ordinarie e
la modalità Esperto mantengono il criterio precedente.

Il pilota su 32 partite con semi nuovi conserva gli stessi esiti della base (1 partita persa,
4 copie bloccate su 1648); non dimostra una riduzione generale delle sconfitte. Sono state scartate
varianti più ampie che miglioravano alcuni esempi ma peggioravano altrove. La ricerca aggiunge
tempo di calcolo solo nei casi critici; una cache limitata evita di ripetere simulazioni uguali.
Parametri, risultati e comandi sono in [data/autopsia/autogioco-rischio/README.md](data/autopsia/autogioco-rischio/README.md).

### Come misurare

Per un controllo servono decine di partite: con 6 partite il risultato dipende soprattutto da quali
pezzi capitano. Succede anche ora: sui 6 semi del comando rapido la versione con i tre pezzi noti perde due
partite che la versione precedente portava a 1.000, ma su 160 partite ne perde la metà.

```bash
npm run sim -- --mode normal --games 30 --seed 19000   # attuale: media 991, 29 a 1.000, 1 persa (prima dei pari merito: 975, 2 perse; circa 10 minuti)
npm run sim -- --mode normal --games 6 --max 1000      # prova veloce, seme 7000: tutte a 1000; punti 10350, 10351, 10798, 10408, 10620, 10206
```

Per confrontare due versioni, lancia lo stesso comando prima e dopo la modifica: con lo stesso seme le
partite sono appaiate. I test di regressione in `tests/unit/strategy.test.js` bloccano il comportamento
attuale: se si cambia la strategia di proposito, si aggiornano i valori attesi. Sono fotografie di poche
partite, non misure di qualità (`pairedCompare` in `scripts/sim-lib.mjs` confronta partita per partita).

**Velocità.** I controlli «il pezzo entra qui?» usano maschere di bit: le 61 celle stanno in due
interi da 32 bit e ogni posizione di ogni pezzo è una maschera precalcolata (`HexGrid.js`). Lo
stesso vale per linee chiudibili, buchi e linee quasi piene in `strategy.js`. Le partite sono
identiche a prima, mossa per mossa (`tests/unit/hexgrid-masks.test.js` confronta le maschere con il
controllo cella per cella); una mossa costa circa 5 ms invece di 42 in modalità normale e 7 invece
di 50 in Esperto. Con il pezzo nuovo alla seconda mossa la modalità normale è risalita a circa 22 ms
per mossa: la prova veloce qui sopra richiede circa 2 minuti (prima delle maschere erano circa 4).
Dal 10 ottobre anche le linee piene si trovano con le maschere (`fullLines`), e dopo una mossa o uno
svuotamento la maschera delle celle piene si aggiorna solo nelle celle toccate (`place`, `clear`):
stesse mosse (semi 7000, 7097, 7194, 2.000 pezzi), circa 17% più veloce (seme 7000: 40,7 s -> 33,6 s).

## Nota

Alveare è un progetto indipendente: regole, pezzi, strategia dell'autogioco e grafica sono stati realizzati da
zero. «Hex FRVR» è citato solo come fonte d'ispirazione.

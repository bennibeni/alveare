# Changelog

## 1.3.0-beta.1 — ordine delle mosse a pari tabellone finale (sperimentale, non adottata nelle app)

Modalità normale, zona di pericolo (sguardo a tre pezzi). Le candidate la cui migliore sequenza porta allo stesso tabellone finale della prima, entro `NORMAL_DEEP_ORDER` (10) punti, sono trattate come pari merito: decide lo spareggio già esistente con il pezzo nuovo. La differenza di totale fra due ordini della stessa sequenza nasce dal conteggio delle linee (120 × affollamento alla prima mossa, 60 più avanti). Nessun peso esistente cambia.

- Partita 2026-11-09, mossa 2573: sceglie la barra 4 in (0, −4) invece della bandiera sinistra in (2, 0). Su quella posizione la barra si blocca meno: 2,69% contro 4,45%, stratificato sui 25 pezzi entranti con 6000 coppie, −1,76 ± 0,28 punti percentuali.
- Conferma preregistrata: 256 coppie nuove, semi 60000000 + 104729·i, fino a 1500 mosse. Punti medi 19462,0 contro 19072,4 (+389,7, IC 97,5% [−104,6; 927,5]). Blocchi 9 contro 15 (8 solo candidata, 14 solo base, McNemar p = 0,29). Nessun endpoint confermato; nessun segnale di peggioramento.
- Prova esplorativa sulle 128 coppie di frammentazione-verifica-generale-v1: +185,7 punti, blocchi 8 contro 11. La soglia 60 è stata scartata (−197 punti, 95 coppie su 128 negative).
- Tempo per mossa invariato (circa 14 ms). Dati: Studio, data/partite/ordine-pari-tabellone-v1/ e 2573-pezzo-entrante/.

## 1.2.0-beta.2 — adozione della beta in Alveare e Studio

Stesse scelte di gioco della beta.1, con correzione dei voti descrittivi nel rinvio della linea: la mossa preferita riceve almeno il voto della migliore alternativa e il voto originale resta in `deferOriginalTotal`, anche nel worker. Evita che il suggerimento sia giudicato inferiore dalla stessa analisi.

La beta viene adottata su richiesta dell’utente dopo la verifica dedicata al rischio: 100 nuove coppie, 301888 continuazioni, rapporto del tasso candidata/base 0,827 con intervallo al 95% [0,477, 1,732], 3 partite principali perse contro 5. Il guadagno di punti è documentato; equivalenza di sicurezza non dimostrata. Le release 1.1.0 e beta.1 restano disponibili per confronto e ripristino.


## 1.2.0-beta.1 — sperimentale, non adottata nelle app

Riduce da 180 a 120 il premio per lo svuotamento immediato in modalità normale. La ricerca, le regole e la modalità Esperto restano invariate.

- 77 posizioni storiche, 20 futuri nuovi ciascuna: +15,33 punti medi con penalità; 51 blocchi per entrambe su 1540 prove.
- 40 partite appaiate su semi nuovi (9000000 + 97*i), massimo 1000 mosse: 12885,48 contro 10832,88 punti medi (+2052,60 ± 260,85, errore standard).
- Partite perse: 2/40 candidata, 1/40 base. Il rischio non è dimostrato equivalente; il criterio di adozione senza sconfitte aggiuntive non è superato. La base stabile rimane 1.1.0.
- I dati e i criteri preregistrati sono nello Studio: data/autopsia/esperimento-77-1.1.0/.


## 1.1.0

Rinvio della linea (modalità normale). A combo 0, se il suggerimento è un punto che chiude linee, la strategia gioca invece il miglior pezzo grande che non chiude nulla. Il pezzo grande deve restare entro `NORMAL_DEFER` (50) punti dal punto e lasciargli almeno altrettante linee da chiudere alla mossa dopo. Cambia solo l'ordine della classifica, non i totali.

- Archivio delle mosse giocate a mano: la strategia sceglie 16 mosse migliori del suggerimento (prima 1) e nessuna peggiore.
- Confronto appaiato su 1000 ingressi in pericolo (8 copie, 30 mosse, stessi pezzi): +2,8 ± 0,2 punti, 15 copie bloccate con entrambe le versioni.
- La modalità Esperto e le scelte di soccorso con poche celle libere non cambiano.

## 1.0.0

Estrazione del motore identico di Alveare e Alveare Studio: regole, pezzi, strategia normale/Esperto, rischio imparato, giudizi, indicatori di rischio e oracolo. Nessuna modifica all’algoritmo.

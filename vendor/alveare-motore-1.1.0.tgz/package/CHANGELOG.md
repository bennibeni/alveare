# Changelog

## 1.1.0

Rinvio della linea (modalità normale). A combo 0, se il suggerimento è un punto che chiude linee, la strategia gioca invece il miglior pezzo grande che non chiude nulla. Il pezzo grande deve restare entro `NORMAL_DEFER` (50) punti dal punto e lasciargli almeno altrettante linee da chiudere alla mossa dopo. Cambia solo l'ordine della classifica, non i totali.

- Archivio delle mosse giocate a mano: la strategia sceglie 16 mosse migliori del suggerimento (prima 1) e nessuna peggiore.
- Confronto appaiato su 1000 ingressi in pericolo (8 copie, 30 mosse, stessi pezzi): +2,8 ± 0,2 punti, 15 copie bloccate con entrambe le versioni.
- La modalità Esperto e le scelte di soccorso con poche celle libere non cambiano.

## 1.0.0

Estrazione del motore identico di Alveare e Alveare Studio: regole, pezzi, strategia normale/Esperto, rischio imparato, giudizi, indicatori di rischio e oracolo. Nessuna modifica all’algoritmo.

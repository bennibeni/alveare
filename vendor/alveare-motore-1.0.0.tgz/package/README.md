# Motore condiviso di Alveare

Il codice di regole, pezzi, scelta delle mosse e analisi vive in `src/`. Non contiene React, interfacce, accessi al browser o dipendenze npm. Alveare e Alveare Studio usano copie installate di pacchetti versionati, non collegamenti alla cartella di sviluppo.

## Sviluppare e rilasciare

1. Modifica il codice in `src/`, non gli adattatori `game/` delle app.
2. Esegui `npm test` e aggiorna i test per cambiamenti intenzionali.
3. Documenta il cambiamento in `CHANGELOG.md`.
4. Esegui `npm run release -- 1.1.0-beta.1` per una prova, oppure `npm run release -- 1.1.0` per una versione stabile.

La release esegue i test, aggiorna la versione e l’impronta del motore, poi crea `releases/alveare-motore-VERSIONE.tgz` e il suo manifest SHA-256. Le versioni già presenti non si sovrascrivono. Non viene pubblicato nulla su npm e nessuna app viene aggiornata automaticamente.

## Provare nello Studio

Dalla cartella di Alveare Studio:

```powershell
npm run motore:aggiorna -- "../alveare-motore/releases/alveare-motore-1.1.0-beta.1.tgz"
npm test
npm run build
```

Confronta poi la nuova strategia su molte partite, con gli stessi semi della base e semi indipendenti. I test verificano correttezza e regressioni, non dimostrano un miglioramento statistico.

## Adottare in Alveare o tornare indietro

Dalla cartella di Alveare esegui lo stesso comando `motore:aggiorna` con il pacchetto approvato. Ogni app conserva le versioni in `vendor/`; per tornare a una versione precedente usa, per esempio, `npm run motore:aggiorna -- vendor/alveare-motore-1.0.0.tgz`.

`npm run motore:versione` in ciascuna app mostra versione e impronta installate. La cartella di sviluppo del motore non è necessaria per eseguire o reinstallare le app: ciascuna conserva il pacchetto utilizzato e il lockfile.

Gli script storici dello Studio continuano a usare le vecchie varianti autonome. Gli script che generano nuove varianti leggono il sorgente della versione installata, non gli adattatori `game/`.

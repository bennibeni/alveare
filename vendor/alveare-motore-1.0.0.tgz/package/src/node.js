import { fileURLToPath } from "node:url";
export const ENGINE_FILES = Object.freeze(["HexGrid.js", "pieces.js", "strategy.js", "learnedRisk.js", "pieceAvailability.js", "moveJudgment.js", "positionRisk.js", "autopsy.js"]);
export const engineDirectory = () => fileURLToPath(new URL("./", import.meta.url));
export function engineFile(name) {
  if (!ENGINE_FILES.includes(name)) throw new Error(`File non appartenente al motore: ${name}`);
  return fileURLToPath(new URL(name, import.meta.url));
}

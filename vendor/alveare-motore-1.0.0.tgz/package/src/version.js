export const ENGINE_VERSION = "1.0.0";
export const ENGINE_HASH = "18da62e07ba0aecaef3942ea7f29659b90cb1cc32900a1bc6ba81a5e4d57048b";

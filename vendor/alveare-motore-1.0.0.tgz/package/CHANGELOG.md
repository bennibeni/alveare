# Changelog

## 1.0.0

Estrazione del motore identico di Alveare e Alveare Studio: regole, pezzi, strategia normale/Esperto, rischio imparato, giudizi, indicatori di rischio e oracolo. Nessuna modifica all’algoritmo.

# Changelog

## 1.2.0-beta.1 — sperimentale, non adottata nelle app

Riduce da 180 a 120 il premio per lo svuotamento immediato in modalità normale. La ricerca, le regole e la modalità Esperto restano invariate.

- 77 posizioni storiche, 20 futuri nuovi ciascuna: +15,33 punti medi con penalità; 51 blocchi per entrambe su 1540 prove.
- 40 partite appaiate su semi nuovi (9000000 + 97*i), massimo 1000 mosse: 12885,48 contro 10832,88 punti medi (+2052,60 ± 260,85, errore standard).
- Partite perse: 2/40 candidata, 1/40 base. Il rischio non è dimostrato equivalente; il criterio di adozione senza sconfitte aggiuntive non è superato. La base stabile rimane 1.1.0.
- I dati e i criteri preregistrati sono nello Studio: data/autopsia/esperimento-77-1.1.0/.


## 1.1.0

Rinvio della linea (modalità normale). A combo 0, se il suggerimento è un punto che chiude linee, la strategia gioca invece il miglior pezzo grande che non chiude nulla. Il pezzo grande deve restare entro `NORMAL_DEFER` (50) punti dal punto e lasciargli almeno altrettante linee da chiudere alla mossa dopo. Cambia solo l'ordine della classifica, non i totali.

- Archivio delle mosse giocate a mano: la strategia sceglie 16 mosse migliori del suggerimento (prima 1) e nessuna peggiore.
- Confronto appaiato su 1000 ingressi in pericolo (8 copie, 30 mosse, stessi pezzi): +2,8 ± 0,2 punti, 15 copie bloccate con entrambe le versioni.
- La modalità Esperto e le scelte di soccorso con poche celle libere non cambiano.

## 1.0.0

Estrazione del motore identico di Alveare e Alveare Studio: regole, pezzi, strategia normale/Esperto, rischio imparato, giudizi, indicatori di rischio e oracolo. Nessuna modifica all’algoritmo.

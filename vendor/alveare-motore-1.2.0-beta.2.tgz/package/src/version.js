export const ENGINE_VERSION = "1.2.0-beta.2";
export const ENGINE_HASH = "ba3ec887468e731be15229c0d05c3d79474cd9d93aae2cadcb01d59ab25c92f9";
